---
templateKey: 'about-page'
path: /about
title: About US
---
### WEB HOSTING COMPANY IN BANGLADESH
Extreme Solutions provides world-class technology solutions for small to enterprise businesses. We are well recognized in Bangladesh for business application development, website design and Web-Hosting related services. Our Windows & Linux Hosting solutions are using by more then 2000 satisfied customers all over the world. We believe that the key to success is to provide professional services at a well balanced price.

### Our Data Centers
To provide you with the fastest access time, reliability, and disaster recovery, we use some of the most advanced datacenters in the USA & Germany. These are equipped with- multiple backbone Internet lines, backup power diesel generators, backup tape libraries, 24/7 surveillance ensuring speed, safety, and redundancy. All of our servers are highly available, and equipped with 100% redundant components! Unlike some of our competitors we never use cheap, unreliable, or non-enterprise hard drives.

### Ultra Fast & Secure Servers
All of our nodes are equipped with the latest & fastest Intel/AMD enterprise processors, latest technology RAM, allowing for plenty of resources for all clients hosted. Protected by CISCO, and application firewalls we offer better security, and protection for common attacks. Using a combination of proprietary software and hardware technologies along with advanced system administration techniques, we are able to offer a faster Hosting environment, thus offering you and your visitors a better overall web experience.

### Network & Server Uptime
We provide you with a 100% uptime guarantee which covers the availability of our servers, as well as all network components in all of our data centers. We monitor our servers 24/7, using the latest technologies available for instant solutions and any kinds of hardware replacements. Our guarantee excludes for Scheduled maintenance time, Problems outside of our network, configuration errors, 3rd party software errors, client abuse or excessive utilization of resources or Malicious attacks.

### ALL PLANS INCLUDES

### Enterprise Level SSD Storage
For optimum performance all of our servers utilize state of the art SSD caching technology, backed by redundant RAID 10 (best performance) topology. We never use cheap, unreliable, or non-enterprise hard drives.

### 24/ 7 Customer Care
Our friendly Support Team is available to help you 24 hours a day, seven days a week for your domain, Hosting and online presence needs. Email, chat or online form submission for support, our friendly and knowledgeable staff is waiting to hear from you.

### Up-to-Date
The most important reason to keep server up to date is security. We understand that it is crucial to maintain up-to-date software for keeping up with current market trends. For that reason, we ensure all our server has all latest updated features with security patches.

### Lowest Price Guarantee!
As we offering the lowest price in the market we are also asuring the same price for renewal of your purchased service. We make sure that you enjoy the low prices as long as you stay with us. All your domains will also under your own account and be movable if you decide to move.

### Free Domain & Website Builde
All our premium Hosting offers sold with free domain and addons. Create your own great looking website in 3 easy steps! Instantly create a ready-to-publish website for your business! Easy SiteBuilder let's you choose from hundreds of layouts, stock images, and industry specific themes.

### Risk Free
We have a 15 DAYS RISK FREE guarantee on ALL shared, reseller & VPS plans. There is no risk for you to sign up and try our great service! During the first 15 days as a client, if you decide to stop your service, we will refund your Hosting fees in full.
